import torch
import torchvision.utils as vutils

def save_sample(generator, data, epoch, path='sample.png'):
    generator.eval()
    x, _ = next(iter(data))
    with torch.no_grad():
        fake = generator(x.cuda())
    vutils.save_image(fake, path, normalize=True)
    generator.train()