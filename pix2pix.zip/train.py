import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torchvision import transforms
from dataset import Pix2PixDataset
from models import UNetGenerator, PatchDiscriminator
from utils import save_sample

EPOCHS = 200
BATCH_SIZE = 8
LR = 2e-4
IMG_SIZE = 256
L1_LAMBDA = 100

device = 'cuda' if torch.cuda.is_available() else 'cpu'

transform = transforms.Compose([
    transforms.Resize((IMG_SIZE, IMG_SIZE)),
    transforms.ToTensor(),
    transforms.Normalize((0.5,), (0.5,))
])
dataset = Pix2PixDataset("data/train", transform)
loader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True)

gen = UNetGenerator().to(device)
disc = PatchDiscriminator().to(device)

opt_gen = torch.optim.Adam(gen.parameters(), lr=LR, betas=(0.5, 0.999))
opt_disc = torch.optim.Adam(disc.parameters(), lr=LR, betas=(0.5, 0.999))

bce = nn.BCELoss()
l1 = nn.L1Loss()

for epoch in range(EPOCHS):
    for batch in loader:
        x, y = [b.to(device) for b in batch]

        fake_y = gen(x)
        real_pred = disc(x, y)
        fake_pred = disc(x, fake_y.detach())
        loss_real = bce(real_pred, torch.ones_like(real_pred))
        loss_fake = bce(fake_pred, torch.zeros_like(fake_pred))
        loss_disc = (loss_real + loss_fake) / 2

        opt_disc.zero_grad()
        loss_disc.backward()
        opt_disc.step()

        fake_pred = disc(x, fake_y)
        adv_loss = bce(fake_pred, torch.ones_like(fake_pred))
        l1_loss = l1(fake_y, y) * L1_LAMBDA
        loss_gen = adv_loss + l1_loss

        opt_gen.zero_grad()
        loss_gen.backward()
        opt_gen.step()

    print(f"Epoch {epoch+1}/{EPOCHS} | Gen Loss: {loss_gen.item():.4f} | Disc Loss: {loss_disc.item():.4f}")
    save_sample(gen, loader, epoch, f'sample_epoch_{epoch+1}.png')