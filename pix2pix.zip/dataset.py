from torch.utils.data import Dataset
from torchvision import transforms
from PIL import Image
import os

class Pix2PixDataset(Dataset):
    def __init__(self, root_dir, transform=None):
        self.files = os.listdir(root_dir)
        self.root_dir = root_dir
        self.transform = transform

    def __len__(self):
        return len(self.files)

    def __getitem__(self, index):
        img_path = os.path.join(self.root_dir, self.files[index])
        image = Image.open(img_path)
        w, h = image.size
        input_img = image.crop((0, 0, w//2, h))
        target_img = image.crop((w//2, 0, w, h))

        if self.transform:
            input_img = self.transform(input_img)
            target_img = self.transform(target_img)
        return input_img, target_img